/* To Do List

-Spritesheet-
Create Allie Sprite (DONE)
Create PickUp Sprite (DONE)
Create background Sprites   (DONE)
    Bushes/Fences (DONE)
    Cityscape/Apt buildings (DONE)
    Road        (DONE)
    Hills/Forest (DONE)
    Clouds  (DONE)
Platforms   (DONE)
FinishLine
Main Menu
    Start Button
    Quit Button

-Audio-
Allie
    Jump
    Idle
Pickup
    Cronch
BGM
Button Select
Game Over
Game Complete
*/