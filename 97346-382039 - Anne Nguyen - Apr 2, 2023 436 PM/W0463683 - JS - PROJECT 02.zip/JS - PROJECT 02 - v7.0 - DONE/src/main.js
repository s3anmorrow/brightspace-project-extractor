// importing the sass stylesheet for bundling
import "./../sass/styles.scss";

import "./../node_modules/spin.js/spin.css";
import { Spinner } from "spin.js";

import { getJSONData } from "./Toolkit";
import { sendJSONData } from "./Toolkit";

let loadingOverlay;

let jsonAlbum;
let index;

//if this is the first time loading the album
let flag = true;

// flag for Comment button to open/ close
let openBtnCmt = true;
let cmtContainer;

// flag for Jump button to open/ close
let openBtnJump = true;
let thumbContainer;

const STUDENT_ID = "w0463683";
const NUMBER_OF_PHOTOS = 11;

// Web API to get the JSON data to
const RETRIEVE_SCRIPT = `https://www.seanmorrow.ca/_lessons/albumRetrieve.php?id=${STUDENT_ID}&count=${NUMBER_OF_PHOTOS}`;

// Web API to send the JSON data to
const SUBMIT_SCRIPT = `https://www.seanmorrow.ca/_lessons/albumAddComment.php?id=${STUDENT_ID}`;

let spinner = new Spinner({ color: "#FFFFFF", lines: 12 }).spin(document.querySelector(".g-loading-overlay"));

// ----------------------------------------- event handlers
function onClickBtnNext() {

    index++;

    resetNextPrevBtn();
    populateAPhoto(index);
}

function onClickBtnPrev() {

    index--;

    resetNextPrevBtn();
    populateAPhoto(index);
}

function onClickBtnOK() {

    /**
     * To submit a new comment to a photo the web app must send JSON in the following format:
            {
                "photoId": [PHOTO ID OF PHOTO TO ADD COMMENT],
                "author": [INPUT AUTHOR],
                "comment": [INPUT COMMENT]
            }
     */

    let authorComment = document.querySelector(".p-section .comment-section #author");
    let contentComment = document.querySelector(".p-section .comment-section #content");

    let checkRequired = checkRequiredTxtFields(authorComment, contentComment);

    if (checkRequired == 1) {

        // Construct the JSON objects / arrays to package the form data
        let sendJSON = {
            "photoId": jsonAlbum.photos[index].id,
            "author": authorComment.value,
            "comment": contentComment.value
        };

        sendJSONData(SUBMIT_SCRIPT, sendJSON, onResponse, onError, true);

        /**
         * Add the new comment to the comment list of the photo on the website
         * <div class="commentBox">
                <div class="author">Submitted by: Daisy Tran</div>
                <div class="content">"Oh, I love that photo so much!!!"</div>
            </div>
         */
        let comtList = document.querySelector(".p-section .photo-section .photoBox .commentList");

        if (comtList == null) {

            comtList = document.createElement("div");
            comtList.setAttribute("class", "commentList");
            document.querySelector(".p-section .photo-section .photoBox").append(comtList);
        }

        // create a new comment box below the photo
        let comtBox = document.createElement("div");
        comtBox.setAttribute("class", "commentBox");
        comtList.prepend(comtBox);

        let authorDiv = document.createElement("div");
        authorDiv.setAttribute("class", "author");
        authorDiv.innerHTML = "Submitted by: " + authorComment.value;
        comtBox.append(authorDiv);

        let contDiv = document.createElement("div");
        contDiv.setAttribute("class", "content");
        contDiv.innerHTML = '\"' + contentComment.value + '\"';
        comtBox.append(contDiv);

        // Remove the comment container
        document.querySelector(".p-section .comment-section .container").remove();
    } else if (checkRequired == 0) {

        // Remove the comment container only
        document.querySelector(".p-section .comment-section .container").remove();
    }
}

function onClickBtnComment() {

    // flag used to control the Comment button 
    // true: open; false: closed
    if (openBtnCmt) {

        /**
         * An “Add Comment” panel that can be opened / closed via a button to add a new comment
         * to the current photo by entering an author name and the comment into two textboxes.
         * Both these fields are required to add a new comment and must be limited to a reasonable
         * number of characters. An ok button must be included to submit the new comment.
         */

        /**
         * A COMMENT CONTAINER HTML DESIGN
         * <div class="container">
         *      <div>Author:</div>
         *      <input id="author" type="text">
         *      <div>Comment (200 Characters):</div>
         *      <div><textarea id="content" placeholder="Enter your comment here..."></textarea></div>
         *      <button id="btnOK">OK</button>
         * </div>
         */

        cmtContainer = document.createElement("div");
        cmtContainer.setAttribute("class", "container");
        document.querySelector(".p-section .comment-section").append(cmtContainer);

        let authorName = document.createElement("div");
        authorName.innerHTML = "Author:";
        cmtContainer.append(authorName);

        let txtAuthorName = document.createElement("input");
        txtAuthorName.setAttribute("type", "text");
        txtAuthorName.setAttribute("id", "author");
        cmtContainer.append(txtAuthorName);

        let comtHeading = document.createElement("div");
        comtHeading.innerHTML = "Comment (200 Characters):";
        cmtContainer.append(comtHeading);

        let divTxtArea = document.createElement("div");
        let txtArea = document.createElement("textarea");
        txtArea.setAttribute("id", "content");
        txtArea.setAttribute("placeholder", "Enter your comment here...");
        txtArea.maxLength = "200";
        divTxtArea.append(txtArea);
        cmtContainer.append(divTxtArea);

        let btnOK = document.createElement("button");
        btnOK.setAttribute("id", "btnOK");
        btnOK.innerHTML = "OK";
        cmtContainer.append(btnOK);

        document.getElementById("btnOK").addEventListener("click", onClickBtnOK);
        openBtnCmt = false;
    } else {
        cmtContainer.remove();
        openBtnCmt = true;
    }
}

function onClickBtnJump() {

    /**
     * A THUMBNAIL PHOTO SECTION HTML DESIGN
     * <div class="thumb-section">
            <img id="0" class="thumb-photo" src="./images/100_1245.jpg">
            <img id="1" class="thumb-photo" src="./images/image6.jpg">
            <img id="2" class="thumb-photo" src="./images/HPIM0259.jpg">
        </div>
     */

    // flag used to control the Comment button 
    // true: open; false: closed
    if (openBtnJump) {

        thumbContainer = document.createElement("div");
        thumbContainer.setAttribute("class", "thumb-section");
        document.querySelector(".p-section").prepend(thumbContainer);

        for (let i = 0; i < NUMBER_OF_PHOTOS; i++) {
            let thumbPhoto = document.createElement("img");
            thumbPhoto.id = i; //index of the photo
            thumbPhoto.setAttribute("class", "thumb-photo");
            thumbPhoto.src = "./images/" + jsonAlbum.photos[i].source;
            thumbPhoto.alt = "thumb_image_here";
            thumbContainer.append(thumbPhoto);

            // handle event 'click' on each thumbphoto
            document.getElementById(`${i}`).addEventListener("click", e => {
                index = i;
                populateAPhoto(index);
                resetNextPrevBtn();
            });
        }

        openBtnJump = false;

    } else {
        thumbContainer.remove();
        openBtnJump = true;
    }

}

function onLoad(responseData) {

    jsonAlbum = responseData;

    // if no photo found
    if (NUMBER_OF_PHOTOS == 0) {

        document.getElementById("photoCount").innerHTML = `Photo 0 of 0`;

        let noPhotoMsg = document.createElement("h2");
        noPhotoMsg.innerHTML = "Sorry, no photo found in the album!!! :(";
        document.querySelector(".p-section").append(noPhotoMsg);
    } else {

        //if this is the first time loading the album
        if (flag) {
            startAlbum();
        }
    }
}

function onResponse(responseText) {

    console.log(`*** response received from Web API: ${responseText}`);
}

function onError(error) {

    console.log(`*** error: ${error.message}`);
}

// --------------------------------------------------------------- private methods
function loadedImage() {

    // after an image is loaded, remove the loading-overlay
    loadingOverlay.style.display = "none";
}

function checkRequiredTxtFields(authorCmt, contCmt) {
    // return 1: all filled
    // return 0: all un-filled
    // return -1: some missing

    authorCmt.style.borderColor = "black";
    contCmt.style.borderColor = "black";

    if (authorCmt.value == "") {
        if (contCmt.value == "") {
            return 0;
        } else {
            authorCmt.style.borderColor = "red";
            return -1;
        }
    } else {
        if (contCmt.value == "") {
            contCmt.style.borderColor = "red";
            return -1;
        } else {
            return 1;
        }
    }
}

function resetNextPrevBtn() {

    // reset Prev and Next buttons
    if (index == 0) {

        document.getElementById("btnNext").disabled = false;
        document.getElementById("btnPrev").disabled = true;
    } else if (index == NUMBER_OF_PHOTOS - 1) {

        document.getElementById("btnNext").disabled = true;
        document.getElementById("btnPrev").disabled = false;
    } else {
        document.getElementById("btnNext").disabled = false;
        document.getElementById("btnPrev").disabled = false;
    }
}

function startAlbum() {

    index = 0;
    populateAPhoto(index);
    // reset flag = false --> need to remove a photo 
    // before display another new one
    flag = false;
    document.getElementById("btnPrev").disabled = true;
}

function populateAPhoto(index) {

    // reset the loading-overlay before loading an image
    loadingOverlay.style.display = "block";

    // request the newest version of the photo with the latest comments
    getJSONData(RETRIEVE_SCRIPT, onLoad, onError, true);

    // flag = true --> no photo needed to be removed in the beginning
    if (!flag) {
        document.querySelector(".p-section .photo-section .photoBox").remove();
    }

    /**
     * PHOTO BOX HTML DESIGN
     * <div class="photoBox">
            <img src="./images/100_1245.jpg" alt="new_image_here">
            <h3>Caption Test</h3>
            <p>This is a test description for the photo above.</p>
            <div class="commentList">
                <div class="commentBox">
                    <div class="author">Submitted by: Anne Nguyen</div>
                    <div class="content">"This photo is so nice!!!"</div>
                </div>
                <div class="commentBox">
                    <div class="author">Submitted by: Daisy Tran</div>
                    <div class="content">"Oh, I love that photo so much!!!"</div>
                </div>
            </div>
        </div>
     */

    // update the photo counting shown on the website
    document.getElementById("photoCount").innerHTML = `Photo ${index + 1} of ${NUMBER_OF_PHOTOS}`;

    // create a photo-box to show all information about the photo
    let photoBox = document.createElement("div");
    document.querySelector(".p-section .photo-section").append(photoBox);
    photoBox.setAttribute("class", "photoBox");

    let newPhoto = document.createElement("img");
    newPhoto.src = "./images/" + jsonAlbum.photos[index].source;
    newPhoto.alt = "new_image_here";
    document.querySelector(".p-section .photo-section .photoBox").append(newPhoto);
    newPhoto.onload = loadedImage();

    let photoTitle = document.createElement("h3");
    photoTitle.innerHTML = jsonAlbum.photos[index].title;
    document.querySelector(".p-section .photo-section .photoBox").append(photoTitle);

    let photoCap = document.createElement("p");
    photoCap.innerHTML = jsonAlbum.photos[index].caption;
    document.querySelector(".p-section .photo-section .photoBox").append(photoCap);

    // show comments
    let comtListDiv = document.createElement("div");
    comtListDiv.setAttribute("class", "commentList");
    document.querySelector(".p-section .photo-section .photoBox").append(comtListDiv);

    let comtList = jsonAlbum.photos[index].comments;

    for (let i = 0; i < comtList.length; i++) {
        // create a new comment box below the photo
        let comtBox = document.createElement("div");
        comtBox.setAttribute("class", "commentBox");
        comtListDiv.append(comtBox);

        let authorDiv = document.createElement("div");
        authorDiv.setAttribute("class", "author");
        authorDiv.innerHTML = "Submitted by: " + comtList[i].author;
        comtBox.append(authorDiv);

        let contDiv = document.createElement("div");
        contDiv.setAttribute("class", "content");
        contDiv.innerHTML = '\"' + comtList[i].comment + '\"';
        comtBox.append(contDiv);
    }

}


// ----------------------------------------- main method
function main() {

    loadingOverlay = document.querySelector(".g-loading-overlay");

    getJSONData(RETRIEVE_SCRIPT, onLoad, onError, true);

    document.getElementById("btnNext").addEventListener("click", onClickBtnNext);
    document.getElementById("btnPrev").addEventListener("click", onClickBtnPrev);
    document.getElementById("btnComt").addEventListener("click", onClickBtnComment);
    document.getElementById("btnJump").addEventListener("click", onClickBtnJump);
}


main();