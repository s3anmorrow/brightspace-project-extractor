// importing the sass stylesheet for bundling
import "./../sass/styles.scss";
import "./../node_modules/@fortawesome/fontawesome-free/css/all.css";
import { sendJSONData, getJSONData } from "./Toolkit";
// spinner.js imports
import "./../node_modules/spin.js/spin.css";
import { Spinner } from "spin.js"; 

let loadingOverlay = document.querySelector(".g-loading-overlay");
let spinner;

const CALL_DELAY = 1000;
// Web API to retrieve the images JSON data from
const RETRIEVE_IMAGES_ENDPOINT = "https://www.seanmorrow.ca/_lessons/albumRetrieve.php?id=";

// Web API to send the JSON data to save comments
const SAVE_COMMENT_ENDPOINT = "https://www.seanmorrow.ca/_lessons/albumAddComment.php?id=";

// student ID to use for the endpoints
const STUDENT_ID = "w0027056";

let numImagesLoaded = 0;
let numImagesToLoad = 11;
let currentImageIndex = 1;
let arrayOfImages = new Array();
let selectedPhoto;
let intervalId;
let autoPlay = false;

// load the requested number of images
function loadImages(imageCount) {

    let endpoint = RETRIEVE_IMAGES_ENDPOINT + STUDENT_ID + "&count=";

    if (imageCount == null) {
        imageCount = 0;
    }

    endpoint = endpoint + imageCount;

    toggleOverlay();
    spinner = new Spinner({color:"white"}).spin(loadingOverlay);

    setTimeout(function(){
        getJSONData(endpoint, onResponse, onError, true); 
    }, CALL_DELAY);

    
}
// handling the data for the images to be loaded
function onResponse(photosResponse) {
    console.log(JSON.stringify(photosResponse));

    let {photos} = photosResponse;

    arrayOfImages = new Array();
    numImagesLoaded = 0;
    currentImageIndex = 1;
    
    photos.forEach(photo => {
        numImagesLoaded = numImagesLoaded + 1;
        arrayOfImages.push(photo);
    });

    if (numImagesLoaded > 0) {
        document.getElementById("noImagesLoaded").style.display = "none";
        document.getElementById("imagesLoaded").style.display = "block";

        selectedPhoto = arrayOfImages[0];
        addPhotosToQuickPanel();
        updateSelectedPhoto(); 
        
    } else {
        document.getElementById("noImagesLoaded").style.display = "block";
        document.getElementById("imagesLoaded").style.display = "none";
    }  

    spinner.stop();

    toggleOverlay();
}   
// saving the new comments, displaying in order and spinner for loading
function onSaveCommentResponse(saveCommentResponse) {
    
    let newCommentJSON = {
        "author": document.getElementById("author").value,
        "comment": document.getElementById("comment").value
    }; 

    selectedPhoto.comments = [newCommentJSON].concat(selectedPhoto.comments);

    showPhotoComments();

    spinner.stop();
    toggleOverlay();

}

function onError(error) {
    console.log(`*****error: ${error.message}`);

    spinner.stop();
    toggleOverlay();
}

// reset the auto play functionality
function resetAutoPlay() {
    let autoPlayElement = document.getElementById("autoPlay");

    autoPlayElement.classList.remove("fa-stop-circle");
    autoPlayElement.classList.add("fa-play-circle");

    clearInterval(intervalId);
    intervalId = null;
    autoPlay = false;
}

// go to the next picture
function goToNextPicture(loopBackToFirst) {

    if (loopBackToFirst==true && currentImageIndex == numImagesLoaded){
        currentImageIndex = 0;
    }

    if (loopBackToFirst!=true && autoPlay==true && intervalId!=null) {
        resetAutoPlay();
    }

    if (currentImageIndex < numImagesLoaded) {
        currentImageIndex = currentImageIndex + 1;

        updateSelectedPhoto();        
    }
}

// go to the previous picture
function goToPreviousPicture() {
    
    if (autoPlay==true && intervalId!=null) {
        resetAutoPlay();
    }

    if (currentImageIndex > 1) {
        currentImageIndex = currentImageIndex - 1;
   
        updateSelectedPhoto();
    }
}

//update the buttons on the UI
function updateButtons() {

    let previousButton = document.getElementById("Previous");
    let nextButton = document.getElementById("Next");

    if (currentImageIndex == numImagesLoaded) {
        nextButton.setAttribute("disabled", "");
    } else {
        nextButton.removeAttribute("disabled");
    }

    if (currentImageIndex == 1) {
        previousButton.setAttribute("disabled", "");
    } else {
        previousButton.removeAttribute("disabled");
    }
}

// update the photo counter text
function updatePhotoCounter() {

    let counterText = currentImageIndex + " / " + numImagesLoaded;
    document.getElementById("photoCounter").innerText = counterText;
} 

// displaying comment in the comment section
function addPhotoComment(commentsSection, author, comment) {
    let currentComment = document.createElement("div");
    let currentAuthor = document.createElement("div");

    if (intervalId!=null){
        clearInterval(intervalId);
        intervalId = null; 
    } 
    
    currentComment.className = "comment";
    currentAuthor.className = "author";
    currentComment.innerText = comment;
    currentAuthor.innerText = author;

    commentsSection.appendChild(currentComment);
    commentsSection.appendChild(currentAuthor);
}

// show photo comments
function showPhotoComments() {

    let commentsSection = document.getElementById("comments");

    commentsSection.innerHTML = "";
      
    if (selectedPhoto.comments == null && selectedPhoto.comments.length == 0) {
        return;
    } 

    selectedPhoto.comments.forEach(comment => {
        addPhotoComment(commentsSection, comment.author, comment.comment);   
    });
}

// clear the selected style for all photos
function clearSelectedIndicator() {
    let thumbnailImages = document.querySelectorAll("#thumbnails>img");

    thumbnailImages.forEach(thumbnailImage => {
        thumbnailImage.classList.remove("selectedPhoto");
    });
}

// set the style for the current selected photo
function setSelectedIndicator() {

    clearSelectedIndicator();

    if (selectedPhoto!=null) {
        let thumbnailImage = document.querySelector("#thumbnails>img[photoid='" + selectedPhoto.id + "']");
        thumbnailImage.classList.add("selectedPhoto");
    }
}

// jump to the desired photo (click on a thumbnail)
function jumpToPhoto(evt) {

    resetAutoPlay();
    clearSelectedIndicator();

    for (let index = 0; index < numImagesLoaded; index++) {
        
        if (evt.currentTarget.photoId == arrayOfImages[index].id) {
            currentImageIndex = index + 1;
            updateSelectedPhoto();   
            break;
        }
    }
} 

// add the photo to the thumbnails list
function addPhotoToThumbnails(thumbnails, photo) {
    
    let currentPhoto = document.createElement("img");

    currentPhoto.addEventListener("click", jumpToPhoto);
    currentPhoto.classList.add("thumbnailImage");

    currentPhoto.src = "./images/" + photo.source;
    currentPhoto.setAttribute("photoId", photo.id);
    currentPhoto.photoId = photo.id;
    
    thumbnails.appendChild(currentPhoto);
}

// add the loaded photos to the thumbnails
function addPhotosToQuickPanel() {

    let thumbnails = document.getElementById("thumbnails");

    thumbnails.innerHTML = "";
      
    arrayOfImages.forEach(photo => {
        addPhotoToThumbnails(thumbnails, photo);
    });
}

function updateSelectedPhoto() {
    selectedPhoto = arrayOfImages[currentImageIndex-1];

    document.getElementById("currentImage").src = "images/" + selectedPhoto.source;
    document.getElementById("photoTitle").innerText = selectedPhoto.title;
    document.getElementById("photoCaption").innerText = selectedPhoto.caption;
    
    showPhotoComments();
    updatePhotoCounter();
    updateButtons();
    setSelectedIndicator();
}

// get the text length of an input field with limited error checking 
function getTextFieldLength(elementId) {
    let element = document.getElementById(elementId);
    if (element === null) {
        console.log("Element can not be found: " + elementId);
        return 0;
    } 
    return element.value.length;
}

// event for text input changing
function onFieldCheck(e) { 

    // check if something is in each textbox 
    let enableButton = ((getTextFieldLength("author") > 0) && (getTextFieldLength("comment") > 0));
    
    //enable or disable the submit button depending on all input fields having text
    enableSubmit(enableButton);     
} 

// enable or disable the submit button
function enableSubmit(enableButton) {

    let submitButton = document.getElementById("saveComment");

    submitButton.disabled = !enableButton;
} 

// show the add comment form
function addComment() {

    resetAutoPlay();

    document.getElementById("author").value = "";
    document.getElementById("comment").value = "";
    document.getElementById("newComment").style.display = "flex";

}

// cancel the add comment form
function cancelComment() {

    document.getElementById("newComment").style.display = "none";
    console.log("cancelling Comment for current photo");
}

// save the new comment for the current selected photo
function saveComment() {

    let endpoint = SAVE_COMMENT_ENDPOINT + STUDENT_ID;

    // construct the JSON objects /arrays to package the form data
    let photoCommentJSON = {
        "photoId": selectedPhoto.id,
        "author": document.getElementById("author").value,
        "comment": document.getElementById("comment").value
    };

    toggleOverlay();
    spinner = new Spinner({color:"white"}).spin(loadingOverlay);

    setTimeout(function(){
        sendJSONData(endpoint, photoCommentJSON, onSaveCommentResponse, onError, true);
    }, CALL_DELAY);

    
    document.getElementById("newComment").style.display = "none";
}

// toggle the thumbnails panel
function onToggleImagePanel() {

    let imagePanel = document.getElementById("imagePanel");
    let filmStrips = document.getElementsByClassName("g-filmStripBackground");
    
    Array.from(filmStrips).forEach(filmStrip => {
        if (filmStrip.style.display == "block") {
            filmStrip.style.display = "none";
        } else {
            filmStrip.style.display = "block";
        }
    });

    if (imagePanel.style.display == "flex") {
        imagePanel.style.display = "none";
    } else {
        imagePanel.style.display = "flex";
    }
}
    
// toggle the auto play functionality
function onToggleAutoPlay() {

    let autoPlayElement = document.getElementById("autoPlay");

    cancelComment();

    autoPlay = !autoPlay;

    if (autoPlay) {
        intervalId = setInterval(goToNextPicture, 2000, true);
        autoPlayElement.classList.remove("fa-play-circle");
        autoPlayElement.classList.add("fa-stop-circle");
    }
    else {
        autoPlayElement.classList.remove("fa-stop-circle");
        autoPlayElement.classList.add("fa-play-circle");
        clearInterval(intervalId);
        intervalId = null;
    }
}

// ---------------------------------------------------------- private methods
function toggleOverlay() {
    loadingOverlay.style.display = ((loadingOverlay.style.display == "block") ? "none" : "block");
}

// --------------------------------------- main method
function main() {
    
    document.getElementById("toggleThumbnails").addEventListener("click", onToggleImagePanel);
    document.getElementById("autoPlay").addEventListener("click", onToggleAutoPlay);
    document.getElementById("author").addEventListener("input", onFieldCheck);
    document.getElementById("comment").addEventListener("input", onFieldCheck);
    document.getElementById("addComment").addEventListener("click", addComment);
    document.getElementById("saveComment").addEventListener("click", saveComment);
    document.getElementById("cancelComment").addEventListener("click", cancelComment);
    document.getElementById("Previous").addEventListener("click", goToPreviousPicture);
    document.getElementById("Next").addEventListener("click", goToNextPicture);
    loadImages(numImagesToLoad);   

}


main();